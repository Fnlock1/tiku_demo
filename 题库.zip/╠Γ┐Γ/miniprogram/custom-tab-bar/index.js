// curtom-tab-bar/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    user_judge:true , //这个是用来判断的  
    user_src:'https://736f-songcaishequ-2gdoi33re7acee25-1308153584.tcb.qcloud.la/%E9%85%8D%E7%BD%AE%E6%96%87%E4%BB%B6/224%E7%94%A8%E6%88%B7.png?sign=9ce2f10e1e99fa91b71b2d688437dbd2&t=1640575628',
    "list": [
      {
        "pagePath": "pages/index/index"
      },
      {
        "pagePath": "pages/user/index"
      }
    ]
  },



    getuser(e){
      console.log(e)
      wx.switchTab({
        url: "/pages/user/index",
      })
      this.data.user_judge=!this.data.user_judge
      
      if(this.data.user_judge===true){
        this.data.user_src='https://736f-songcaishequ-2gdoi33re7acee25-1308153584.tcb.qcloud.la/%E9%85%8D%E7%BD%AE%E6%96%87%E4%BB%B6/224%E7%94%A8%E6%88%B7.png?sign=9ce2f10e1e99fa91b71b2d688437dbd2&t=1640575628'
      }else if(this.data.user_judge===false){
        this.data.user_src='https://736f-songcaishequ-2gdoi33re7acee25-1308153584.tcb.qcloud.la/%E9%85%8D%E7%BD%AE%E6%96%87%E4%BB%B6/user1.png?sign=9fa7b75af5ce4327397766fdbdae142d&t=1640575822'
      }

 
    
    },

    getindex(e){
      console.log(e)
      wx.switchTab({
        url: "/pages/index/index",
      })
      this.data.user_judge=!this.data.user_judge
      
    },


    getset(){
     wx.navigateTo({
       url: '../add/index',
     })
    },



    
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})