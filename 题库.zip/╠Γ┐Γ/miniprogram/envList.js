const envList = [{"envId":"cloud1-6gzlih0e0447f9a6","alias":"cloud1"},{"envId":"songcaishequ-2gdoi33re7acee25","alias":"songcaishequ"}]
const isMac = false
module.exports = {
    envList,
    isMac
}