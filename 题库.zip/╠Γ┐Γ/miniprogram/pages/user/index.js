// pages/user/index.js
const app=getApp()
const db=wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
      page_no_login:true,   // 未登录页面显示判断
      page_yes_login:false,   // 未登录页面显示判断
      head_img:'',   //用户头像
      head_name:'',  //用户名字
      head_title:'',    //用户签名
      openid:'',   //用户的openid
      user_length:''
    },

  demo(){   //登录  判断
    wx.getUserProfile({
      desc: 'desc',
    }).then((res)=>{
        app.userinfo=res.userInfo
        app.userinfo.judge=this.data.page_no_login
        app.add_jus=true
        this.setData({
          page_no_login:false,
          page_yes_login:true,
          head_img:res.userInfo.avatarUrl,
          head_name:res.userInfo.nickName 
        })

        db.collection('user').where({
          _openid:this.data.openid
        }).get().then(res=>{
         this.setData({
            head_title:res.data[0].title
         })
         let num_length=res.data.length
         if(num_length ===0){
           db.collection('user').add({
             data:{
               name:app.userinfo.nickName,
               head_img:app.userinfo.avatarUrl,
               title:'这里太小，介绍不了我'
             }
           })
         }
        })

        })
    
        wx.cloud.callFunction({
          name:'quickstartFunctions',
          data: {
            type: 'getOpenId'
          }                          //12.28 目前还没用上
        }).then(res=>{
            this.setData({
              openid:res.result.openid
            })
        })

      
      
        
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})